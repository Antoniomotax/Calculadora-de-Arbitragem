function calcular() {
    const odd1 = parseFloat(document.getElementById("odd1").value);
    const odd2 = parseFloat(document.getElementById("odd2").value);
    const total = parseFloat(document.getElementById("total").value);

    if (!odd1 || !odd2 || !total) {
        document.getElementById("resultado").innerHTML =
        "<p style='color:#ff4444'>Preencha todos os campos!</p>";
        return;
    }

    const soma = (1/odd1) + (1/odd2);

    if (soma >= 1) {
        document.getElementById("resultado").innerHTML =
        "<p style='color:#ff4444'>❌ Não existe arbitragem com essas odds.</p>";
        return;
    }

    const aposta1 = (total / odd1) / soma;
    const aposta2 = (total / odd2) / soma;

    const retorno1 = aposta1 * odd1;
    const retorno2 = aposta2 * odd2;

    const lucroMin = Math.min(retorno1, retorno2) - total;
    const lucroMax = Math.max(retorno1, retorno2) - total;

    document.getElementById("resultado").innerHTML = `
        <p style="color:#4CAF50;font-weight:bold">✔ Arbitragem Encontrada!</p>
        <p><strong>Aposte Casa 1:</strong> R$ ${aposta1.toFixed(2)}</p>
        <p><strong>Aposte Casa 2:</strong> R$ ${aposta2.toFixed(2)}</p>
        <p><strong>Lucro mínimo:</strong> R$ ${lucroMin.toFixed(2)}</p>
        <p><strong>Lucro máximo:</strong> R$ ${lucroMax.toFixed(2)}</p>
    `;
}

/* --- Instalação do APP (PWA) --- */

let eventoInstalacao;

window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    eventoInstalacao = e;

    const btn = document.getElementById("btnInstalar");
    btn.style.display = "block";

    btn.addEventListener("click", () => {
        btn.style.display = "none";
        eventoInstalacao.prompt();
    });
});
